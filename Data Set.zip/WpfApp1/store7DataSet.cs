﻿namespace WpfApp1
{


    partial class store7DataSet
    {
        partial class ProductsDataTable
        {
        }

        partial class CategoriesDataTable
        {
        }
    }
}

namespace WpfApp1.store7DataSetTableAdapters
{
    partial class CategoriesTableAdapter
    {
    }

    public partial class OrdersTableAdapter {
    }
}
