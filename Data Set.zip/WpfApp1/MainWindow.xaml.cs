﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.DataSet1TableAdapters;

namespace WpfApp1
{

    public partial class MainWindow : Window
    {
        CategoriesTableAdapter categories = new CategoriesTableAdapter();
        OrdersTableAdapter orders = new OrdersTableAdapter();
        ProductsTableAdapter products = new ProductsTableAdapter();

        public MainWindow()
        {
            InitializeComponent();
            gridProducts.ItemsSource = products.GetData();
            gridOrders.ItemsSource = orders.GetData();
            gridCategories.ItemsSource = categories.GetData();
        }

        private void AddCategory_Click(object sender, RoutedEventArgs e)
        {
            string categoryName = txtCategoryName.Text.Trim();

            if (!string.IsNullOrWhiteSpace(categoryName))
            {
                categories.Insert(categoryName);
                gridCategories.ItemsSource = categories.GetData();
                txtCategoryName.Clear();
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите название категории.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(txtProductId.Text, out int productId) &&
                int.TryParse(txtQuantity.Text, out int quantity) &&
                decimal.TryParse(txtTotalPrice.Text, out decimal totalPrice) &&
                dpOrderDate.SelectedDate.HasValue)
            {
                DateTime orderDate = dpOrderDate.SelectedDate.Value;

                orders.Insert(productId, quantity, totalPrice, orderDate);
                gridOrders.ItemsSource = orders.GetData();
                txtProductId.Clear();
                txtQuantity.Clear();
                txtTotalPrice.Clear();
                dpOrderDate.SelectedDate = null;
            }
            else
            {
                MessageBox.Show("Введите нормальные данные для ProductID, Quantity, TotalPrice, and OrderDate.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(txtCategoryId.Text, out int categoryId) &&
                decimal.TryParse(txtPrice.Text, out decimal price) &&
                !string.IsNullOrWhiteSpace(txtProductName.Text.Trim()))
            {
                string productName = txtProductName.Text.Trim();

                products.Insert(productName, categoryId, price);
                gridProducts.ItemsSource = products.GetData();
                txtProductName.Clear();
                txtCategoryId.Clear();
                txtPrice.Clear();
            }
            else
            {
                MessageBox.Show("Введите нормальные данные для ProductName, CategoryID, and Price.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (gridProducts.SelectedItem != null)
            {
                DataRowView row = (DataRowView)gridProducts.SelectedItem;

                // Заполнение текстовых полей данными выбранной строки для редактирования
                txtProductName.Text = row["ProductName"].ToString();
                txtCategoryId.Text = row["CategoryID"].ToString();
                txtPrice.Text = row["Price"].ToString();
            }
            else if (gridOrders.SelectedItem != null)
            {
                DataRowView row = (DataRowView)gridOrders.SelectedItem;

                // Заполнение текстовых полей данными выбранной строки для редактирования
                txtProductId.Text = row["ProductID"].ToString();
                txtQuantity.Text = row["Quantity"].ToString();
                txtTotalPrice.Text = row["TotalPrice"].ToString();
                dpOrderDate.SelectedDate = Convert.ToDateTime(row["OrderDate"]);
            }
            else if (gridCategories.SelectedItem != null)
            {
                DataRowView row = (DataRowView)gridCategories.SelectedItem;

                // Заполнение текстовых полей данными выбранной строки для редактирования
                txtCategoryName.Text = row["CategoryName"].ToString();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите продукт, заказ или категорию для редактирования.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            if (gridProducts.SelectedItem != null)
            {
                DataRowView row = (DataRowView)gridProducts.SelectedItem;
                int productId = Convert.ToInt32(row["ProductID"]);
                string productName = txtProductName.Text;
                int categoryId = Convert.ToInt32(txtCategoryId.Text);
                decimal price = Convert.ToDecimal(txtPrice.Text);

                // Здесь обновляем данные в базе данных
                products.Update(productName, categoryId, price, productId, row["ProductName"].ToString(), Convert.ToInt32(row["CategoryID"]), Convert.ToDecimal(row["Price"]));

                // Обновляем таблицу gridProducts
                gridProducts.ItemsSource = products.GetData();
            }
            else if (gridOrders.SelectedItem != null)
            {
                DataRowView row = (DataRowView)gridOrders.SelectedItem;
                int orderId = Convert.ToInt32(row["OrderID"]);
                int productId = Convert.ToInt32(txtProductId.Text);
                int quantity = Convert.ToInt32(txtQuantity.Text);
                decimal totalPrice = Convert.ToDecimal(txtTotalPrice.Text);
                DateTime orderDate = dpOrderDate.SelectedDate.Value;

                // Здесь обновляем данные в базе данных
                orders.Update(productId, quantity, totalPrice, orderDate, orderId, Convert.ToInt32(row["ProductID"]), Convert.ToInt32(row["Quantity"]), Convert.ToDecimal(row["TotalPrice"]), Convert.ToDateTime(row["OrderDate"]));

                // Обновляем таблицу gridOrders
                gridOrders.ItemsSource = orders.GetData();
            }
            else if (gridCategories.SelectedItem != null)
            {
                DataRowView row = (DataRowView)gridCategories.SelectedItem;
                int categoryId = Convert.ToInt32(row["CategoryID"]);
                string categoryName = txtCategoryName.Text;

                // Здесь обновляем данные в базе данных
                categories.Update(categoryName, categoryId, row["CategoryName"].ToString());

                // Обновляем таблицу gridCategories
                gridCategories.ItemsSource = categories.GetData();
            }
        }


        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (gridProducts.SelectedItem != null)
            {
                DataRowView row = (DataRowView)gridProducts.SelectedItem;
                int productId = Convert.ToInt32(row["ProductID"]);
                string productName = row["ProductName"].ToString();
                int categoryId = Convert.ToInt32(row["CategoryID"]);
                decimal price = Convert.ToDecimal(row["Price"]);

                // Удаляем данные из базы данных
                products.Delete(productId, productName, categoryId, price);

                // Обновляем таблицу gridProducts
                gridProducts.ItemsSource = products.GetData();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите продукт для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteOrder_Click(object sender, RoutedEventArgs e)
        {
            if (gridOrders.SelectedItem != null)
            {
                DataRowView row = (DataRowView)gridOrders.SelectedItem;
                int orderId = Convert.ToInt32(row["OrderID"]);
                int productId = Convert.ToInt32(row["ProductID"]);
                int quantity = Convert.ToInt32(row["Quantity"]);
                decimal totalPrice = Convert.ToDecimal(row["TotalPrice"]);
                DateTime orderDate = Convert.ToDateTime(row["OrderDate"]);

                // Удаляем данные из базы данных
                orders.Delete(orderId, productId, quantity, totalPrice, orderDate);

                // Обновляем таблицу gridOrders
                gridOrders.ItemsSource = orders.GetData();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите заказ для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteCategory_Click(object sender, RoutedEventArgs e)
        {
            if (gridCategories.SelectedItem != null)
            {
                DataRowView row = (DataRowView)gridCategories.SelectedItem;
                int categoryId = Convert.ToInt32(row["CategoryID"]);
                string categoryName = row["CategoryName"].ToString();

                // Удаляем данные из базы данных
                categories.Delete(categoryId, categoryName);

                // Обновляем таблицу gridCategories
                gridCategories.ItemsSource = categories.GetData();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите категорию для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

    }
}
