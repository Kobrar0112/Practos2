﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private store7Entities categories = new store7Entities();
        private store7Entities orders = new store7Entities();
        private store7Entities products = new store7Entities();

        public MainWindow()
        {
            InitializeComponent();
            gridProducts.ItemsSource = products.Products.ToList();
            gridOrders.ItemsSource = orders.Orders.ToList();
            gridCategories.ItemsSource = categories.Categories.ToList();
        }

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var newProduct = new Products
                {
                    ProductName = txtProductName.Text,
                    CategoryID = int.Parse(txtCategoryId.Text),
                    Price = decimal.Parse(txtPrice.Text)
                };

                products.Products.Add(newProduct);
                products.SaveChanges();
                gridProducts.ItemsSource = products.Products.ToList();
                MessageBox.Show("Продукт успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (gridProducts.SelectedItem != null)
            {
                var selectedProduct = gridProducts.SelectedItem as Products;
                selectedProduct.ProductName = txtProductName.Text;
                selectedProduct.CategoryID = int.Parse(txtCategoryId.Text);
                selectedProduct.Price = decimal.Parse(txtPrice.Text);

                products.SaveChanges();
                gridProducts.Items.Refresh();
                MessageBox.Show("Продукт успешно изменен.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите продукт для изменения.");
            }
        }

       

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (gridProducts.SelectedItem != null)
            {
                var selectedProduct = gridProducts.SelectedItem as Products;
                products.Products.Remove(selectedProduct);
                products.SaveChanges();
                gridProducts.ItemsSource = products.Products.ToList();
                MessageBox.Show("Продукт успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите продукт для удаления.");
            }
        }

        private void AddOrder_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var newOrder = new Orders
                {
                    ProductID = int.Parse(txtProductId.Text),
                    Quantity = int.Parse(txtQuantity.Text),
                    TotalPrice = decimal.Parse(txtTotalPrice.Text),
                    OrderDate = dpOrderDate.SelectedDate.Value
                };

                orders.Orders.Add(newOrder);
                orders.SaveChanges();
                gridOrders.ItemsSource = orders.Orders.ToList();
                MessageBox.Show("Заказ успешно добавлен.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void DeleteOrder_Click(object sender, RoutedEventArgs e)
        {
            if (gridOrders.SelectedItem != null)
            {
                var selectedOrder = gridOrders.SelectedItem as Orders;
                orders.Orders.Remove(selectedOrder);
                orders.SaveChanges();
                gridOrders.ItemsSource = orders.Orders.ToList();
                MessageBox.Show("Заказ успешно удален.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите заказ для удаления.");
            }
        }

        private void AddCategory_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var newCategory = new Categories
                {
                    CategoryName = txtCategoryName.Text
                };

                categories.Categories.Add(newCategory);
                categories.SaveChanges();
                gridCategories.ItemsSource = categories.Categories.ToList();
                MessageBox.Show("Категория успешно добавлена.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void DeleteCategory_Click(object sender, RoutedEventArgs e)
        {
            if (gridCategories.SelectedItem != null)
            {
                var selectedCategory = gridCategories.SelectedItem as Categories;
                categories.Categories.Remove(selectedCategory);
                categories.SaveChanges();
                gridCategories.ItemsSource = categories.Categories.ToList();
                MessageBox.Show("Категория успешно удалена.");
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите категорию для удаления.");
            }
        }

         private void ProductsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (gridProducts.SelectedItem != null)
            {
                var selectedProduct = gridProducts.SelectedItem as Products;
                txtProductName.Text = selectedProduct.ProductName;
                txtCategoryId.Text = selectedProduct.CategoryID.ToString();
                txtPrice.Text = selectedProduct.Price.ToString();
            }
        }

        private void OrdersGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (gridOrders.SelectedItem != null)
            {
                var selectedOrder = gridOrders.SelectedItem as Orders;
                txtProductId.Text = selectedOrder.ProductID.ToString();
                txtQuantity.Text = selectedOrder.Quantity.ToString();
                txtTotalPrice.Text = selectedOrder.TotalPrice.ToString();
                dpOrderDate.SelectedDate = selectedOrder.OrderDate;
            }
        }

        private void CategoriesGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (gridCategories.SelectedItem != null)
            {
                var selectedCategory = gridCategories.SelectedItem as Categories;
                txtCategoryName.Text = selectedCategory.CategoryName;
            }
        }



    }
}